#include "FileIO.h"
#include <iostream>
using namespace std;



FileIO::FileIO(string employeeId[], string lastName[], string firstName[], string birthDate[], string gender[], string startDate[], double salary[], int employeeNum);
{
	employeeId = eId;
	lastName = lName;
	firstName = fName;
	birthDate = bDate;
	gender = gen;
	startDate = sDate;
	salary = sal;
	employeeNumber = employeeNum
}



/**

Instruction wise, unsure of what was required to be put here. I attempted to create a few private/public member functions to run the IO methods as part of a fileIO class
but it didn't work as intended and seemed to be more backwards than simply placing the IO functions in the main file.


**/






